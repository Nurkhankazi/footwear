<?php

register_nav_menus( array(
    'primary' => __( 'Top primary menu', 'shows' ),
    'secondary' => __( 'Secondary menu', 'shows' ),
    ) );

add_theme_support( 'post-thumbnails' );
add_theme_support( 'custom-logo' );

/* custome post type */

add_action('init','register_ims_post_type',0);
function register_ims_post_type(){
    $slider_labels=array(
        'name'=>__('Slider','ims'),
        'singular_name'=>__('Slider','ims'),
        'add_new'=>__('Add New Slider','ims'),
        'add_new_item'=>__('Add New Slider','ims'),
        'edit_item'=>__('Edit Slider','ims'),
        'new_item'=>__('New Slider','ims'),
        'view_item'=>__('View Slider','ims'),
        'search_item'=>__('Search Slider','ims'),
        'not_found'=>__('No Slider Found','ims'),
        'not_found_in_trash'=>__('No Slider Found in Trash','ims'),
        'parent_item_colon'=>__('Parent Slide:','ims'),
        'menu_name'=>__('Slides','ims'),
    );

    $slider_args=[
        'labels'=>$slider_labels,
        'description'=>__('Add your home page slides', 'ims'),
        'supports'=>array('title','thumbnail'),
        'public'=>true,
        'show_ui'=>true,
        'show_ui_menu'=>true,
        'menu_icon'=>get_stylesheet_directory_uri().'/images/slider.png',
        'show_in_nav_menu'=>true,
        'publicly_queryable'=>true,
        'exclude_from_search'=>true,
        'has_archive'=>false,
        'query_var'=>true,
        'can_export'=>true,
        'rewrite'=>true,
        'capability_type'=>'post'
    ];

    register_post_type('slider',$slider_args);
}