Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></span> 
							<span class="block">Demo Images: <a href="http://unsplash.co/" target="_blank">Unsplash</a> , <a href="http://pexels.com/" target="_blank">Pexels.com</a></span>
						</p>
					</div>
				</div>
			</div>
		</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="ion-ios-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="<?= get_template_directory_uri() ?>/js/jquery.min.js"></script>
   <!-- popper -->
   <script src="<?= get_template_directory_uri() ?>/js/popper.min.js"></script>
   <!-- bootstrap 4.1 -->
   <script src="<?= get_template_directory_uri() ?>/js/bootstrap.min.js"></script>
   <!-- jQuery easing -->
   <script src="<?= get_template_directory_uri() ?>/js/jquery.easing.1.3.js"></script>
	<!-- Waypoints -->
	<script src="<?= get_template_directory_uri() ?>/js/jquery.waypoints.min.js"></script>
	<!-- Flexslider -->
	<script src="<?= get_template_directory_uri() ?>/js/jquery.flexslider-min.js"></script>
	<!-- Owl carousel -->
	<script src="<?= get_template_directory_uri() ?>/js/owl.carousel.min.js"></script>
	<!-- Magnific Popup -->
	<script src="<?= get_template_directory_uri() ?>/js/jquery.magnific-popup.min.js"></script>
	<script src="<?= get_template_directory_uri() ?>/js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="<?= get_template_directory_uri() ?>/js/bootstrap-datepicker.js"></script>
	<!-- Stellar Parallax -->
	<script src="<?= get_template_directory_uri() ?>/js/jquery.stellar.min.js"></script>
	<!-- Main -->
	<script src="<?= get_template_directory_uri() ?>/js/main.js"></script>

	</body>
</html>

